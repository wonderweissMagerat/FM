#include <sstream>
#include "pc_frame.h"

bool pc_frame::init(pc_task &task, int t_num, int buf_size, int log_num) {
    pTask = &task;
    threadNum = t_num;
    bufSize = buf_size;
    logNum = log_num;
    sem_init(&semPro, 0, 1); //https://blog.csdn.net/qyz_og/article/details/47189219
    sem_init(&semCon, 0, 0);
    threadVec.clear();
    threadVec.push_back(thread(&pc_frame::proThread, this));// 单生产者
    for (int i = 0; i < threadNum; ++i) {
        threadVec.push_back(thread(&pc_frame::conThread, this, i));// 多消费者
    }
    return true;
}


void pc_frame::run() {
    for (int i = 0; i < threadVec.size(); ++i) {
        threadVec[i].join();
    }
}

void pc_frame::proThread() {
    string line;
    int line_num = 0;
    int i = 0;
    bool finished_flag = false;//是否读完数据的标记
    int log_value = 0;
    stringstream str;
    while (true) {
        sem_getvalue(&semPro, &log_value);
        str.clear();
        str << "proThread 等待生产 semPro" << log_value << endl;
//        printf("%s", str.str().c_str());
        sem_wait(&semPro);// semPro初始值为1，等着semPro>0，阻塞接收信号等待生产，解除后semPro = semPro-1
        sem_getvalue(&semPro, &log_value);
        str.clear();
        str << "proThread 开始生产 semPro" << log_value << endl;
//        printf("%s", str.str().c_str());
        bufMtx.lock();// 进入临界区 加锁
        for (i = 0; i < bufSize; ++i) {
            if (!getline(cin, line)) {
                finished_flag = true;
                break;
            }
            line_num++;
            buffer.push(line);
            if (line_num % logNum == 0) {
                cout << line_num << " lines have finished" << endl;
            }
        }
        bufMtx.unlock();
        sem_post(&semCon);// semCon+1，新生产了一个，通知消费者消费
        sem_getvalue(&semCon, &log_value);
        str.clear();
        str << "proThread 生产完成了一个 semCon" << log_value << endl;
//        printf("%s", str.str().c_str());
        if (finished_flag)// 跳出while
        {
            break;
        }
    }
    sem_getvalue(&semPro, &log_value);
    str.clear();
    str << "proThread 全部生产结束" << log_value << endl;
//    printf("%s", str.str().c_str());
}


void pc_frame::conThread(int thread_tag) {
    bool finished_flag = false;// 判断是否消费完了
    vector<string> input_vec;
    input_vec.reserve(bufSize);
    int log_value = 0;
    stringstream str;
    while (true) {
        input_vec.clear();
        sem_getvalue(&semCon, &log_value);
        str.clear();
        for (int j = 0; j < thread_tag+1; ++j) {
            str <<"\t\t\t\t";
        }
        str << "conThread" << thread_tag << " 等待消费 semCon" << log_value << endl;
//        printf("%s", str.str().c_str());
        sem_wait(&semCon);// semCon初始值为0，等着semCon>0，阻塞接收信号等待消费，解除后semCon = semCon-1
        sem_getvalue(&semCon, &log_value);
        str.clear();
        for (int j = 0; j < thread_tag+1; ++j) {
            str <<"\t\t\t\t";
        }
        str << "conThread" << thread_tag << " 开始消费 semCon" << log_value << endl;
//        printf("%s", str.str().c_str());
        bufMtx.lock();
        for (int i = 0; i < bufSize; ++i) {
            if (buffer.empty()) {
                finished_flag = true;
                break;
            }
            input_vec.push_back(buffer.front());
            buffer.pop();
        }
        bufMtx.unlock();
        sem_post(&semPro);// semPro+1，新消费了一个，通知生产者生产
        sem_getvalue(&semPro, &log_value);
        str.clear();
        for (int j = 0; j < thread_tag+1; ++j) {
            str <<"\t\t\t\t";
        }
        str << "conThread" << thread_tag << " 开始训练 semPro" << log_value << endl;
//        printf("%s", str.str().c_str());
        pTask->run_task(input_vec);
        str.clear();
        for (int j = 0; j < thread_tag+1; ++j) {
            str <<"\t\t\t\t";
        }
        str << "conThread" << thread_tag << " 训练完成" << endl;
//        printf("%s", str.str().c_str());
        if (finished_flag) {
            break;
        }
    }
    sem_post(&semCon);// finished_flag == true结束之后semCon+1，通知消费者立即执行
    sem_getvalue(&semCon, &log_value);
    str.clear();
    for (int j = 0; j < thread_tag+1; ++j) {
        str <<"\t\t\t\t";
    }
    str << "conThread" << thread_tag << " 通知消费 semCon" << log_value << endl;
//    printf("%s", str.str().c_str());
}

